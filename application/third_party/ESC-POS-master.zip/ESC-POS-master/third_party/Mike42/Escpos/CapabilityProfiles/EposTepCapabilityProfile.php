<?php
namespace Escpos\CapabilityProfiles;

class EposTepCapabilityProfile extends DefaultCapabilityProfile {
	// TODO override list of code pages
}
